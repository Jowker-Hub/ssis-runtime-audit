/* =============================================================================
   12_executables.sql
   Extraction fondamentale synthetique. Une ligne par executable logique et
   par execution, quel que soit le nombre d'occurrences dans les boucles.

   Source     : catalog.executable_statistics, catalog.executables
   Logging    : Basic
   Sortie     : Executables.csv
   Grain      : execution_id + executable_id

   La reduction a lieu AVANT la normalisation des chemins. Une boucle de
   plusieurs millions d'occurrences ne transfere ainsi qu'une ligne par tache,
   tout en conservant les compteurs et distributions de duree.
   ============================================================================= */

SET NOCOUNT ON;

WITH
retenues AS (
    SELECT e.execution_id, e.folder_name, e.project_name
    FROM SSISDB.[catalog].executions AS e
    WHERE e.start_time IS NOT NULL
      AND (@DebutFenetre IS NULL OR e.start_time >= @DebutFenetre)
      AND (@FinFenetre   IS NULL OR e.start_time <  @FinFenetre)
),
stats_agregees AS (
    SELECT
        s.execution_id,
        s.executable_id,
        MIN(s.execution_path) AS chemin_representatif,
        MIN(s.start_time) AS heure_debut,
        CASE WHEN COUNT_BIG(*) = COUNT(s.end_time) THEN MAX(s.end_time) END AS heure_fin,
        MIN(DATEPART(TZOFFSET, s.start_time)) AS decalage_utc_minutes,
        COUNT_BIG(*) AS nombre_occurrences,
        SUM(CONVERT(decimal(38, 4), ISNULL(s.execution_duration, 0))) AS duree_totale,
        MIN(CONVERT(decimal(38, 4), s.execution_duration)) AS duree_min,
        AVG(CONVERT(decimal(38, 4), s.execution_duration)) AS duree_moyenne,
        MAX(CONVERT(decimal(38, 4), s.execution_duration)) AS duree_max,
        SUM(CASE WHEN s.execution_result = 0 THEN CONVERT(bigint, 1) ELSE 0 END) AS NombreReussites,
        SUM(CASE WHEN s.execution_result = 1 THEN CONVERT(bigint, 1) ELSE 0 END) AS NombreEchecs,
        SUM(CASE WHEN s.execution_result = 2 THEN CONVERT(bigint, 1) ELSE 0 END) AS NombreTerminees,
        SUM(CASE WHEN s.execution_result = 3 THEN CONVERT(bigint, 1) ELSE 0 END) AS NombreAnnulees
    FROM SSISDB.[catalog].executable_statistics AS s
    JOIN retenues AS r ON r.execution_id = s.execution_id
    GROUP BY s.execution_id, s.executable_id
),
nettoyage AS (
    SELECT execution_id, executable_id,
           CAST(chemin_representatif AS nvarchar(4000)) AS chemin,
           0 AS niveaux
    FROM stats_agregees

    UNION ALL

    SELECT n.execution_id, n.executable_id,
           CAST(STUFF(n.chemin,
                      CHARINDEX(N'[', n.chemin),
                      CHARINDEX(N']', n.chemin, CHARINDEX(N'[', n.chemin))
                        - CHARINDEX(N'[', n.chemin) + 1,
                      N'') AS nvarchar(4000)),
           n.niveaux + 1
    FROM nettoyage AS n
    WHERE CHARINDEX(N'[', n.chemin) > 0
      AND CHARINDEX(N']', n.chemin, CHARINDEX(N'[', n.chemin)) > CHARINDEX(N'[', n.chemin)
      AND SUBSTRING(n.chemin,
                    CHARINDEX(N'[', n.chemin) + 1,
                    CHARINDEX(N']', n.chemin, CHARINDEX(N'[', n.chemin))
                      - CHARINDEX(N'[', n.chemin) - 1) NOT LIKE N'%[^0-9]%'
),
chemins AS (
    SELECT execution_id, executable_id, chemin, niveaux
    FROM (
        SELECT execution_id, executable_id, chemin, niveaux,
               ROW_NUMBER() OVER (
                   PARTITION BY execution_id, executable_id
                   ORDER BY niveaux DESC) AS rang
        FROM nettoyage
    ) AS classes
    WHERE rang = 1
)
SELECT
    a.execution_id                                             AS ExecutionId,
    r.folder_name                                              AS Dossier,
    r.project_name                                             AS Projet,
    a.executable_id                                            AS ExecutableId,
    ISNULL(CONVERT(nvarchar(50), x.executable_guid), N'')      AS ExecutableGuid,
    ISNULL(x.executable_name, N'')                             AS Executable,
    ISNULL(x.package_name, N'')                                AS Package,
    ISNULL(x.package_path, N'')                                AS CheminPackage,
    c.chemin                                                   AS CheminLogique,
    c.niveaux                                                  AS NiveauxIterationMax,
    CASE WHEN CHARINDEX(N'[', c.chemin) > 0 THEN N'False' ELSE N'True' END
                                                               AS NormalisationComplete,
    LEN(c.chemin) - LEN(REPLACE(c.chemin, N'\', N''))          AS Profondeur,
    CASE WHEN LEN(c.chemin) - LEN(REPLACE(c.chemin, N'\', N'')) = 1
         THEN N'True' ELSE N'False' END                        AS EstRacine,
    CONVERT(varchar(40), a.heure_debut, 127)                   AS HeureDebut,
    ISNULL(CONVERT(varchar(40), a.heure_fin, 127), N'')        AS HeureFin,
    a.decalage_utc_minutes                                     AS DecalageUtcMinutes,
    a.nombre_occurrences                                       AS NombreOccurrences,
    a.duree_totale                                             AS DureeMillisecondes,
    a.duree_min                                                AS DureeMinMillisecondes,
    a.duree_moyenne                                            AS DureeMoyenneMillisecondes,
    a.duree_max                                                AS DureeMaxMillisecondes,
    a.NombreReussites                                         AS NombreReussites,
    a.NombreEchecs                                            AS NombreEchecs,
    a.NombreTerminees                                         AS NombreTerminees,
    a.NombreAnnulees                                          AS NombreAnnulees,
    CASE WHEN a.NombreEchecs > 0 THEN 1
         WHEN a.NombreAnnulees > 0 THEN 3
         WHEN a.NombreTerminees > 0 THEN 2
         ELSE 0 END                                             AS ResultatCode,
    CASE WHEN a.NombreEchecs > 0 THEN N'Echec'
         WHEN a.NombreAnnulees > 0 THEN N'Annule'
         WHEN a.NombreTerminees > 0 THEN N'Termine'
         ELSE N'Reussi' END                                     AS Resultat
FROM stats_agregees AS a
JOIN retenues AS r ON r.execution_id = a.execution_id
JOIN chemins AS c
  ON c.execution_id = a.execution_id
 AND c.executable_id = a.executable_id
LEFT JOIN SSISDB.[catalog].executables AS x
  ON x.execution_id = a.execution_id
 AND x.executable_id = a.executable_id
ORDER BY a.execution_id, a.executable_id
OPTION (MAXRECURSION 32);
