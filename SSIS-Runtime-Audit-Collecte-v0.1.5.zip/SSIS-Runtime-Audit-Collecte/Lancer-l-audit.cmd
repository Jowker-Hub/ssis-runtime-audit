@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Application\Lancer-l-audit.ps1" -DossierCollectes "%~dp0Collectes"
echo.
pause
endlocal
