/* =============================================================================
   13_messages.sql
   Synthese des messages d'erreur et d'alerte. Une ligne regroupe les
   repetitions d'un meme signal dans une execution.

   Source     : catalog.event_messages
   Logging    : Basic
   Sortie     : Messages.csv
   Grain      : execution + package + type + code + evenement + composant

   Le texte des messages ne sort jamais. Il peut contenir des chemins reseau,
   des chaines de connexion, des requetes ou des valeurs metier.

   PARAMETRES ATTENDUS
     @DebutFenetre datetimeoffset(7)
     @FinFenetre   datetimeoffset(7)

   Les types retenus restent versions dans cette requete :
     100 annulation de requete, 110 avertissement,
     120 erreur, 130 echec de tache.

   Le fichier conserve les colonnes exigees par le modele Power BI actuel.
   MessageId, HeureMessage et CheminExecution sont representatifs du groupe.
   NombreOccurrences et DerniereOccurrence prepareront le futur modele agrege.
   ============================================================================= */

SET NOCOUNT ON;

WITH
retenues AS (
    SELECT e.execution_id, e.folder_name, e.project_name
    FROM SSISDB.[catalog].executions AS e
    WHERE e.start_time IS NOT NULL
      AND (@DebutFenetre IS NULL OR e.start_time >= @DebutFenetre)
      AND (@FinFenetre   IS NULL OR e.start_time <  @FinFenetre)
),
bornes AS (
    /* Le BETWEEN ne change pas le resultat : la jointure sur retenues reste la
       condition exacte. Il donne toutefois au moteur une plage explicite sur
       operation_id au lieu de lui laisser balayer toute la retention SSISDB. */
    SELECT MIN(execution_id) AS execution_id_min,
           MAX(execution_id) AS execution_id_max
    FROM retenues
),
messages_filtres AS (
    SELECT
        m.event_message_id,
        m.operation_id,
        m.message_time,
        m.message_type,
        m.package_name,
        m.message_code,
        m.event_name,
        m.message_source_name,
        m.message_source_id,
        m.subcomponent_name,
        m.execution_path,
        r.folder_name,
        r.project_name,
        /* Les noms peuvent atteindre 4 000 caracteres. Les empreintes gardent
           une cle de regroupement de taille fixe sans tronquer les libelles. */
        HASHBYTES('SHA2_256', CONVERT(varbinary(8000), ISNULL(m.event_name, N'')))
            AS evenement_cle,
        HASHBYTES('SHA2_256', CONVERT(varbinary(8000), ISNULL(m.subcomponent_name, N'')))
            AS sous_composant_cle
    FROM SSISDB.[catalog].event_messages AS m
    CROSS JOIN bornes AS b
    JOIN retenues AS r ON r.execution_id = m.operation_id
    WHERE b.execution_id_min IS NOT NULL
      AND m.operation_id BETWEEN b.execution_id_min AND b.execution_id_max
      AND m.message_type IN (100, 110, 120, 130)
),
messages_agreges AS (
    SELECT
        MIN(m.event_message_id) AS MessageId,
        m.operation_id AS ExecutionId,
        m.folder_name AS Dossier,
        m.project_name AS Projet,
        ISNULL(m.package_name, N'') AS Package,
        m.message_type AS TypeCode,
        m.message_code AS CodeMessage,
        MIN(ISNULL(m.event_name, N'')) AS Evenement,
        MIN(ISNULL(m.message_source_name, N'')) AS Source,
        MIN(ISNULL(m.subcomponent_name, N'')) AS SousComposant,
        MIN(ISNULL(CONVERT(nvarchar(4000), m.execution_path), N'')) AS CheminExecution,
        MIN(m.message_time) AS HeureMessage,
        MAX(m.message_time) AS DerniereOccurrence,
        DATEPART(TZOFFSET, MIN(m.message_time)) AS DecalageUtcMinutes,
        COUNT_BIG(*) AS NombreOccurrences
    FROM messages_filtres AS m
    GROUP BY
        m.operation_id,
        m.folder_name,
        m.project_name,
        m.package_name,
        m.message_type,
        m.message_code,
        m.message_source_id,
        m.evenement_cle,
        m.sous_composant_cle
)
SELECT
    m.MessageId                                                   AS MessageId,
    m.ExecutionId                                                 AS ExecutionId,
    m.Dossier                                                     AS Dossier,
    m.Projet                                                      AS Projet,
    m.Package                                                     AS Package,
    m.TypeCode                                                    AS TypeCode,
    CASE m.TypeCode
        WHEN 100 THEN N'AnnulationRequete'
        WHEN 110 THEN N'Avertissement'
        WHEN 120 THEN N'Erreur'
        WHEN 130 THEN N'EchecTache'
        ELSE N'Inconnu' END                                       AS Type,
    m.CodeMessage                                                 AS CodeMessage,
    m.Evenement                                                   AS Evenement,
    m.Source                                                      AS Source,
    m.SousComposant                                               AS SousComposant,
    m.CheminExecution                                             AS CheminExecution,
    CONVERT(varchar(40), m.HeureMessage, 127)                     AS HeureMessage,
    m.DecalageUtcMinutes                                          AS DecalageUtcMinutes,
    m.NombreOccurrences                                           AS NombreOccurrences,
    CONVERT(varchar(40), m.DerniereOccurrence, 127)               AS DerniereOccurrence
FROM messages_agreges AS m
ORDER BY m.ExecutionId, m.HeureMessage, m.MessageId
OPTION (RECOMPILE);
