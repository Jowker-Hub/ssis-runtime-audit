function Test-SsisRuntimeAuditConnection {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Serveur, [System.Management.Automation.PSCredential]$Identifiants)
    $connexion = New-RuntimeAuditConnexion -Instance $Serveur -Identifiants $Identifiants
    try {
        $commande = $connexion.CreateCommand()
        try {
            $commande.CommandText = 'SELECT SYSDATETIMEOFFSET();'
            $instant = $commande.ExecuteScalar()
            return [pscustomobject]@{ Succes=$true; Serveur=$Serveur; Version=$connexion.ServerVersion; HorodatageServeur=$instant }
        }
        finally { $commande.Dispose() }
    }
    finally { $connexion.Dispose() }
}
