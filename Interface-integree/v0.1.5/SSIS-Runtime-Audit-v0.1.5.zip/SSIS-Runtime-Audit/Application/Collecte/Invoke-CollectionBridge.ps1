# PowerShell 5.1 bridge. Request is received once on stdin, never in arguments.
$ErrorActionPreference = 'Stop'
$WarningPreference = 'SilentlyContinue'
$VerbosePreference = 'SilentlyContinue'
$InformationPreference = 'SilentlyContinue'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
function Send-Envelope {
    param($Value)
    [Console]::Out.WriteLine(($Value | ConvertTo-Json -Depth 12 -Compress))
    [Console]::Out.Flush()
}
$cancelSignal = $null
$credential = $null
try {
    $payload = [Console]::In.ReadLine() | ConvertFrom-Json
    Send-Envelope @{ kind='identity'; data=@{ processIdentity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name } }
    Import-Module (Join-Path $PSScriptRoot 'SsisRuntimeAudit.psd1') -Force -ErrorAction Stop
    if ($payload.cancelEvent) { $cancelSignal = [System.Threading.EventWaitHandle]::OpenExisting($payload.cancelEvent) }
    $request = $payload.request
    if ($request.Username) {
        $secure = ConvertTo-SecureString $request.Password -AsPlainText -Force
        $credential = New-Object System.Management.Automation.PSCredential($request.Username, $secure)
        $request.Password = $null
    }
    switch ($payload.action) {
        'plan' {
            $plan = @(Get-SsisRuntimeAuditPlan)
            Send-Envelope @{ kind='result'; data=$plan }
        }
        'test' {
            $tested = Test-SsisRuntimeAuditConnection -Serveur $request.Server -Identifiants $credential
            Send-Envelope @{ kind='result'; data=$tested }
        }
        'collect' {
            $parameters = @{
                Serveur=$request.Server; Sortie=$request.OutputDirectory; SansFenetre=$true
                Identifiants=$credential; Tout=[bool]$request.All
                SurProgression={ param($e) Send-Envelope @{ kind='progress'; data=$e } }
                AnnulationDemandee={ $cancelSignal -and $cancelSignal.WaitOne(0) }
                ErrorAction='Continue'; ErrorVariable='collectionErrors'
            }
            if ($request.Days) { $parameters.Jours = [int]$request.Days }
            if ($request.Keys) { $parameters.Audit = [string[]]$request.Keys }
            $result = Invoke-SsisRuntimeAudit @parameters 2>$null
            if ($null -eq $result) { throw 'No collection result.' }
            Send-Envelope @{ kind='result'; data=$result }
        }
        default { throw 'Unknown bridge action.' }
    }
}
catch {
    # Never echo arbitrary SQL/provider messages or request content.
    $diagnosticCode = $_.Exception.GetType().Name + ':' + $_.InvocationInfo.ScriptLineNumber
    $sqlDiagnostic = $null
    $currentException = $_.Exception
    while ($null -ne $currentException -and $null -eq $sqlDiagnostic) {
        $number = $currentException.PSObject.Properties['Number']
        $class = $currentException.PSObject.Properties['Class']
        $state = $currentException.PSObject.Properties['State']
        if ($null -ne $number -and $null -ne $class -and $null -ne $state) {
            $sqlDiagnostic = 'SQL ' + [int]$number.Value + ', classe ' + [int]$class.Value + ', etat ' + [int]$state.Value
        }
        $currentException = $currentException.InnerException
    }
    if ($payload.action -eq 'plan') { $diagnosticCode += ' ' + $_.Exception.Message }
    $safeDiagnostic = if ($null -ne $sqlDiagnostic) { $sqlDiagnostic } else { $diagnosticCode }
    Send-Envelope @{ kind='error'; message=('Operation impossible. Verifiez la connexion, les droits SSISDB et les fichiers du module. Code: ' + $safeDiagnostic) }
    exit 1
}
finally {
    if ($cancelSignal) { $cancelSignal.Dispose() }
    if ($credential) { $credential.Password.Dispose() }
}
