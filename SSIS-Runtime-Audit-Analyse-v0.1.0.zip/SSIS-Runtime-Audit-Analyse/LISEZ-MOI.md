# SSIS Runtime Audit — Analyse

Ce dossier sert à analyser une collecte sur une machine équipée de **Power BI Desktop
2.157.1354 ou version ultérieure**.

## Ouvrir une collecte

1. Copiez le dossier `Run_...` entier dans `Donnees\`.
2. Double-cliquez sur `Ouvrir-l-analyse.cmd`.
3. Dans Power BI Desktop, cliquez sur **Actualiser**.

Le lanceur vérifie la collecte, configure automatiquement son chemin local et ouvre le rapport
avec la version compatible la plus récente de Power BI. Si plusieurs dossiers sont présents,
le rapport utilise le `Run_...` le plus récent par défaut.

## Confidentialité

Les données d'un dossier `Run_...` sont potentiellement confidentielles : noms de projets,
packages, machines et faits d'exécution. Transférez-les et conservez-les uniquement par les
canaux autorisés par le client. L'archive d'analyse d'origine ne contient aucune donnée client.
