@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Application\Ouvrir-l-analyse.ps1" -Racine "%~dp0"
if errorlevel 1 pause
endlocal
