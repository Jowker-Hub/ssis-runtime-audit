# =============================================================================
# Ouvrir-l-analyse.ps1
# Configure le rapport sur les donnees placees a cote du livrable et l'ouvre.
# Regle du module : aucun caractere non-ASCII dans ce fichier.
# =============================================================================

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string] $Racine = (Split-Path -Parent $PSScriptRoot),

    [Parameter(Mandatory = $false)]
    [switch] $SansOuverture,

    [Parameter(Mandatory = $false)]
    [object[]] $InstallationsPowerBi
)

$ErrorActionPreference = 'Stop'
$versionMinimale = [version] '2.157.1354'
$Racine = [System.IO.Path]::GetFullPath($Racine)
$dossierDonnees = Join-Path $Racine 'Donnees'
$projetPowerBi = Join-Path $Racine 'Application\powerbi\SsisRuntimeAudit.pbip'
$expressions = Join-Path $Racine 'Application\powerbi\SsisRuntimeAudit.SemanticModel\definition\expressions.tmdl'

if (-not (Test-Path -LiteralPath $dossierDonnees -PathType Container)) {
    throw "Aucune collecte : le dossier Donnees est absent. Copier un dossier Run_... complet dans $dossierDonnees"
}

$runs = @(Get-ChildItem -LiteralPath $dossierDonnees -Directory -Filter 'Run_*' -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending)
if ($runs.Count -eq 0) {
    throw "Aucune collecte dans $dossierDonnees. Copier un dossier Run_... complet puis relancer."
}

$run = $runs[0]
$manquants = @('Run.csv', 'Extractions.csv') |
    Where-Object { -not (Test-Path -LiteralPath (Join-Path $run.FullName $_) -PathType Leaf) }
if ($manquants.Count -gt 0) {
    throw "La collecte la plus recente est incomplete ($($run.Name)). Fichier(s) absent(s) : $($manquants -join ', '). Copier le dossier Run_... entier."
}

if (-not (Test-Path -LiteralPath $expressions -PathType Leaf)) {
    throw "Modele Power BI incomplet : fichier introuvable : $expressions"
}
if (-not (Test-Path -LiteralPath $projetPowerBi -PathType Leaf)) {
    throw "Projet Power BI introuvable : $projetPowerBi"
}

$octets = [System.IO.File]::ReadAllBytes($expressions)
$aBom = ($octets.Length -ge 3 -and $octets[0] -eq 239 -and $octets[1] -eq 187 -and $octets[2] -eq 191)
$texte = [System.IO.File]::ReadAllText($expressions)
$motif = '(?m)^expression DossierBase = ".*" meta \[IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true\](?=\r?$)'
$correspondances = [regex]::Matches($texte, $motif)
if ($correspondances.Count -ne 1) {
    throw "Parametre DossierBase invalide : une definition attendue, $($correspondances.Count) trouvee(s)."
}

$cheminM = $dossierDonnees.Replace('"', '""')
$nouvelleLigne = 'expression DossierBase = "' + $cheminM + '" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
$nouveauTexte = [regex]::Replace($texte, $motif, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $nouvelleLigne })
if ($nouveauTexte -cne $texte) {
    [System.IO.File]::WriteAllText(
        $expressions,
        $nouveauTexte,
        (New-Object System.Text.UTF8Encoding($aBom)))
}

if ($null -eq $InstallationsPowerBi) {
    $InstallationsPowerBi = @()
    $programme = 'C:\Program Files\Microsoft Power BI Desktop\bin\PBIDesktop.exe'
    if (Test-Path -LiteralPath $programme -PathType Leaf) {
        $InstallationsPowerBi += [PSCustomObject]@{
            Origine = 'Program Files'
            Version = [version]([System.Diagnostics.FileVersionInfo]::GetVersionInfo($programme).FileVersion)
            Chemin  = $programme
        }
    }

    try {
        foreach ($paquet in @(Get-AppxPackage -Name '*PowerBIDesktop*' -ErrorAction SilentlyContinue)) {
            if ($paquet) {
                $executable = Join-Path $paquet.InstallLocation 'bin\PBIDesktop.exe'
                if (Test-Path -LiteralPath $executable -PathType Leaf) {
                    $InstallationsPowerBi += [PSCustomObject]@{
                        Origine = 'Microsoft Store'
                        Version = [version]$paquet.Version
                        Chemin  = $executable
                    }
                }
            }
        }
    }
    catch { }
}

$compatibles = @($InstallationsPowerBi |
    Where-Object { [version]$_.Version -ge $versionMinimale } |
    Sort-Object { [version]$_.Version } -Descending)
if ($compatibles.Count -eq 0) {
    $detectees = @($InstallationsPowerBi | ForEach-Object { [string]$_.Version }) -join ', '
    if (-not $detectees) { $detectees = 'aucune' }
    throw "Power BI Desktop $versionMinimale ou superieur est requis. Version(s) detectee(s) : $detectees."
}

$powerBi = $compatibles[0]
Write-Host ''
Write-Host "  Collecte : $($run.Name)" -ForegroundColor Cyan
Write-Host "  Donnees  : $dossierDonnees"
Write-Host "  Power BI : $($powerBi.Version) ($($powerBi.Origine))"
Write-Host ''

if (-not $SansOuverture) {
    Start-Process -FilePath $powerBi.Chemin -ArgumentList ('"' + $projetPowerBi + '"')
}
