# SSIS Runtime Audit — Analyse

Ce dossier sert à analyser une collecte sur une machine équipée de **Power BI Desktop
2.157.1354 ou version ultérieure**.

## Ouvrir une collecte

1. Après le téléchargement, ouvrez les propriétés du ZIP, cochez **Débloquer**, puis appliquez.
2. Décompressez entièrement l'archive.
3. Copiez le dossier `Run_...` entier dans `Donnees\`.
4. Double-cliquez sur `Ouvrir-l-analyse.cmd`.
5. Dans Power BI Desktop, cliquez sur **Actualiser**.

Cette étape de déblocage est nécessaire sur les postes où la stratégie PowerShell est
`RemoteSigned`. Elle ne demande pas de droits administrateur.

Le lanceur vérifie la collecte, configure automatiquement son chemin local et ouvre le rapport
avec la version compatible la plus récente de Power BI. Si plusieurs dossiers sont présents,
le rapport utilise le `Run_...` le plus récent par défaut.

## Confidentialité

Les données d'un dossier `Run_...` sont potentiellement confidentielles : noms de projets,
packages, machines et faits d'exécution. Transférez-les et conservez-les uniquement par les
canaux autorisés par le client. L'archive d'analyse d'origine ne contient aucune donnée client.
