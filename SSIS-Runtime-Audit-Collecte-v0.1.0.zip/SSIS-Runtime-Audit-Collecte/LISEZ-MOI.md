# SSIS Runtime Audit — Collecte

Ce dossier sert uniquement à collecter les faits d'exécution depuis SSISDB. Il fonctionne avec
Windows PowerShell 5.1, sans installation et sans droits administrateur locaux.

## Lancer

1. Décompressez entièrement l'archive dans un dossier local accessible en écriture.
2. Double-cliquez sur `Lancer-l-audit.cmd`.
3. Choisissez l'instance SQL Server et l'authentification Windows ou SQL.
4. Vérifiez les constats du pré-vol, choisissez la période, puis lancez la collecte.

Le compte SQL utilisé doit déjà disposer des droits de lecture nécessaires dans SSISDB. L'outil
travaille en **lecture seule** : il ne crée, ne modifie et ne supprime aucun objet sur le serveur.

## Récupérer le résultat

Chaque exécution produit un dossier `Collectes\Run_AAAAMMJJ-HHMMSSZ`.

Copiez le dossier `Run_...` entier vers la machine équipée de Power BI. Ne prenez pas les CSV
séparément : `Run.csv` et `Extractions.csv` décrivent la collecte et les données éventuellement
indisponibles.

Sur l'autre machine, déposez ce dossier dans `Donnees\` du livrable d'analyse.
