# SSIS Runtime Audit — Collecte

Ce dossier sert uniquement à collecter les faits d'exécution depuis SSISDB. Il fonctionne avec
Windows PowerShell 5.1, sans installation et sans droits administrateur locaux.

## Lancer

1. Après le téléchargement, ouvrez les propriétés du ZIP, cochez **Débloquer**, puis appliquez.
2. Décompressez entièrement l'archive dans un dossier local accessible en écriture.
3. Double-cliquez sur `Lancer-l-audit.cmd`.
4. Choisissez l'instance SQL Server et l'authentification Windows ou SQL.
5. Choisissez les deux derniers jours, une plage de dates inclusive, ou toute la rétention.
6. Vérifiez les constats du pré-vol, puis lancez la collecte.

La borne haute est figée au démarrage selon l'heure SQL Server. Toutes les extractions portent
ainsi exactement sur la même période, même si de nouvelles exécutions démarrent pendant le run.

Cette étape de déblocage est nécessaire sur les postes où la stratégie PowerShell est
`RemoteSigned`. Elle ne demande pas de droits administrateur.

Le compte SQL utilisé doit déjà disposer des droits de lecture nécessaires dans SSISDB. L'outil
travaille en **lecture seule** : il ne crée, ne modifie et ne supprime aucun objet sur le serveur.

## Volume du détail par tâche

`Executables.csv` regroupe les occurrences d'une même tâche dans chaque exécution. C'est le
fichier compact utilisé par Power BI.

`IterationsExecutables.csv` conserve le détail brut, une ligne par occurrence. Cette extraction
avancée est **désactivée par défaut**, car son volume peut atteindre plusieurs centaines de Mo.
Ne l'activez que pour une investigation ciblée sur une période courte.

## Volume des messages

`Messages.csv` regroupe les répétitions d'un même signal dans chaque exécution. Les colonnes
`NombreOccurrences`, `HeureMessage` et `DerniereOccurrence` conservent son volume et ses bornes
temporelles sans transférer chaque répétition. Le texte sensible des messages n'est jamais extrait.

Le modèle Power BI actuel peut charger ce fichier compact, mais ses compteurs affichent encore le
nombre de groupes jusqu'à l'adaptation ultérieure des mesures à `NombreOccurrences`.

## Récupérer le résultat

Chaque exécution produit un dossier `Collectes\Run_AAAAMMJJ-HHMMSSZ`.

Copiez le dossier `Run_...` entier vers la machine équipée de Power BI. Ne prenez pas les CSV
séparément : `Run.csv` et `Extractions.csv` décrivent la collecte et les données éventuellement
indisponibles.

Sur l'autre machine, déposez ce dossier dans `Donnees\` du livrable d'analyse.
